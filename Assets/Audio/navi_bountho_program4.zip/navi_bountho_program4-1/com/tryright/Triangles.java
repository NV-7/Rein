/**
 * Name: Navi Bountho
 * Date: 2/19/2026
 * Professor: Dr. Donahoo
 * Counts the number of right triangles that can be formed from a set of points in a 2D Cartesian plane.
 * Outputs a text file called output.txt with the number of points, time taken to read points, and time taken to count triangles.
 */
package com.tryright;

import java.util.HashMap;
import java.util.Map;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class Triangles {

    static double readTime, countTime;
    static int total;
    static String errorMessage = "";

    static class Point {
        int x, y;

        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    /**
     * Main method to read points from a file. Uses BufferedReader with a 16kb
     * buffer to reduce read system calls.
     * 
     * @param args
     */
    public static void main(String[] args) {

        // Checks if the argumets are valid for Triangles and ProcessTriangles

        boolean isProcess = (args.length == 4 && args[3].equals("Process"));

        if (!isValidTriangles(args) && !isProcess) {
            System.out.println(errorMessage);
            return;
        }

        PointStore pointStore = null;

        // If argument is valid, read the points in pointStore using
        // BinPointStore for .dat files and TextPointStore for .txt files.
        try {

            if (args[0].endsWith(".dat")) {
                pointStore = new BinPointStore(args[0]);
            } else {
                pointStore = new TextPointStore(args[0]);
            }

            int numberOfPoints = pointStore.numPoints();
            int start = 0;
            int end = numberOfPoints;

            // If ProcessTriangles is calling this method will use the start and end indices
            // from ProcessTriangles
            if (isProcess) {
                start = Integer.parseInt(args[1]);
                end = Integer.parseInt(args[2]);
            }

            total = count(pointStore, start, end);

            // Returns the count to process if called by ProcessTriangles, otherwise prints
            // the count and time taken to count triangles.
            if (isProcess) {
                System.out.println(total + "," + countTime);
            } else {
                System.out.println(total);
                writeOutput("Triangles ", countTime, total, numberOfPoints);
            }

            // Writes count and time to test/output.txt

        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            if (pointStore != null) {
                pointStore.close();
            }
        }
    }

    /**
     * Counts the number of right triangles that can be formed from the points in
     * the given range (start, end).
     * Uses negative reciprocal slopes to count the number of right triangles.
     * 
     * @param pointStore The PointStore containing the points to be processed.
     * @param start      The starting point
     * @param end        The ending ending point.
     * @return The number of right triangles.
     */
    public static int count(PointStore pointStore, int start, int end) {

        double startTime = System.currentTimeMillis();
        int sum = 0;
        int dx, dy, divisor;
        String key, negReciprocal;
        int n = pointStore.numPoints();

        for (int i = start; i < end; i++) {
            Map<String, Integer> map = new HashMap<>();

            int x = pointStore.getX(i);
            int y = pointStore.getY(i);

            for (int j = 0; j < n; j++) {
                if (j == i) {
                    continue;
                }
                dx = pointStore.getX(j) - x;
                dy = pointStore.getY(j) - y;

                divisor = gcd(Math.abs(dx), Math.abs(dy));
                key = (dx / divisor) + "." + (dy / divisor);
                map.put(key, map.getOrDefault(key, 0) + 1);
            }
            for (String slope : map.keySet()) {
                String[] parts = slope.split("\\.");
                dx = Integer.parseInt(parts[0]);
                dy = Integer.parseInt(parts[1]);
                negReciprocal = (-dy) + "." + (dx);
                if (map.containsKey(negReciprocal)) {
                    sum += map.get(slope) * map.get(negReciprocal);
                }
            }
            map.clear();
        }
        double endTime = System.currentTimeMillis();
        countTime = endTime - startTime;

        return sum;
    }

    /**
     * Finds and returns the greatest common divisor.
     */
    public static int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }

    /**
     * Writes the output to a file called output.txt in the test directory.
     */
    public static void writeOutput(String method, double countTime, int total, int numberOfPoints) {
        try {

            BufferedWriter writer = new BufferedWriter(
                    new FileWriter("test//output.txt", true));
            writer.write("Method : " + method + "\n"
                    + "Number of Points: " + numberOfPoints + "\n"
                    + "Total Right Triangles: " + total + "\n"
                    + "Time taken to count triangles (ms): " + countTime + "\n"
                    +
                    "\n");
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * Validates the arguments for the ProcessTriangles class.
     * 
     * @param args The command line arguments to validate.
     * 
     * @return true if the arguments are valid, false otherwise.
     */
    public static boolean isValid(String[] args) {

        if (args.length < 2) {
            setErrorMessage("Provide the input file containing the points and number of proccesses as arguments.");
            return false;
        } else if (args.length > 2) {
            setErrorMessage("Too many arguments provided. Provide only the input file and number of processes.");
            return false;
        } else if (Integer.parseInt(args[1]) < 1) {
            setErrorMessage("Number of processes must be at least 1.");
            return false;
        } else if (args[0] == null || args[0].isEmpty()) {
            setErrorMessage("Input file path is invalid.");
            return false;
        }

        return true;
    }

    /*
     * Validates the arguments for the Triangles class.
     * 
     * @param args The command line arguments to validate.
     * 
     * @return true if the arguments are valid, false otherwise.
     */
    public static boolean isValidTriangles(String[] args) {

        if (args.length < 1) {
            setErrorMessage("Provide the input file containing the points as an argument.");
            return false;
        } else if (args.length > 1) {
            setErrorMessage("Too many arguments provided. Provide only the input file.");
            return false;
        } else if (args[0] == null || args[0].isEmpty()) {
            setErrorMessage("Input file path is invalid.");
            return false;
        }

        return true;
    }

    /*
     * Sets the error message to be printed when the arguments are invalid.
     * 
     * @param message The error message to be set.
     */
    public static void setErrorMessage(String message) {
        errorMessage = message + "\n";
    }

}
