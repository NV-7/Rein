package com.tryright;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
import java.io.File;

/**
 * Name: Navi Bountho
 * Date: 2/5//2026
 * Professor: Dr. Donahoo
 * Description: TextPointStorre implemnts PointStore interface to read points
 * from a text file.
 */

public class TextPointStore implements PointStore {

    private int[] xPoints;
    private int[] yPoints;

    public TextPointStore(String filename) throws IOException {
        if (filename == null || filename.isEmpty()) {
            throw new IllegalArgumentException("Filename cannot be null or empty");
        }
        File f = new File(filename);
        if (!f.exists()) {
            throw new IOException("File not found: " + filename);
        } else if (!f.canRead()) {
            throw new IOException("No permission to read file: " + filename);
        }
        getPoints(filename);
    }

    // Reads the points from the given file and stores them in xPoints and yPoints
    // arrays. Uses BufferedReader with a 16kb buffer to reduce read system calls.
    private void getPoints(String filename) throws IOException {

        try (BufferedReader reader = new BufferedReader(
                new FileReader(filename), 16 * 1024)) {

            String firstline = reader.readLine();

            if (firstline == null) {
                throw new IOException("File is empty: " + filename);
            }

            int numberOfPoints = Integer.parseInt(firstline.trim());

            String line;
            StringTokenizer st;
            xPoints = new int[numberOfPoints];
            yPoints = new int[numberOfPoints];
            // Reads points from the file and stores them in xPoints and yPoints arrays
            // Throws an exception if the number of points specified in the file does not
            // match the actual number of points read, or if there are extra points beyond
            // the specified number.
            for (int i = 0; i < numberOfPoints; i++) {
                line = reader.readLine();

                if (line == null && i < numberOfPoints) {
                    throw new IOException("Less points found in the file than specified: expected " + numberOfPoints
                            + ", found " + i + ".");
                }
                st = new StringTokenizer(line);
                int x = Integer.parseInt(st.nextToken());
                int y = Integer.parseInt(st.nextToken());
                xPoints[i] = x;
                yPoints[i] = y;
            }

            // Checks for extra points beyond the specified number of points and throws an
            // exception if found.
            if (reader.readLine() != null) {
                throw new IOException("Extra points found in the file beyond the specified number: expected "
                        + numberOfPoints + ".");
            }

        } catch (FileNotFoundException fn) {
            String fString = fn.getMessage();
            if (fString != null && fString.contains("Permission denied")) {
                throw new IOException("No permission to read file: " + filename);
            } else if (fString != null && fString.contains("No such file or directory")) {
                throw new IOException("File not found: " + filename);
            } else {
                throw new IOException("File error: " + fn.getMessage());
            }
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Error reading input file: " + e.getMessage());
        }
    }

    @Override
    public void close() {

    }

    /**
     * Returns the number of points in the list of points
     * 
     * @return The number of points in the list of points
     */
    @Override
    public int numPoints() {
        return xPoints.length;
    }

    /**
     * Returns the x points from the list of x points
     * 
     * @param idx The index of the x point to return
     * @return The x point at the given index
     */
    @Override
    public int getX(int idx) {
        if (idx < 0 || idx >= xPoints.length) {
            throw new IndexOutOfBoundsException("Index out of bounds: " + idx);
        }
        return xPoints[idx];
    }

    /**
     * Retuns the y points from the list of y points
     * 
     * @param idx The index of the y point to return
     * @return The y point at the given index
     */
    @Override
    public int getY(int idx) {
        if (idx < 0 || idx >= yPoints.length) {
            throw new IndexOutOfBoundsException("Index out of bounds: " + idx);
        }
        return yPoints[idx];
    }

}
