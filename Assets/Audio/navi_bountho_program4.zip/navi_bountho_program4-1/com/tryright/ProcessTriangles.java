package com.tryright;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Name: Navi Bountho
 * Date: 2/5//2026
 * Professor: Dr. Donahoo
 * Counts the number of right triangles in a set of points using multithreading
 */

public class ProcessTriangles {
    public static void main(String[] args) {

        // Validates the arguments before proceeding
        if (Triangles.isValid(args) == false) {
            System.out.println(Triangles.errorMessage);
            return;
        }

        // Set of proccesses to count triangles.
        String classpath = System.getProperty("java.class.path");
        String javaHome = System.getProperty("java.home");
        String javaCommand = javaHome + "/bin/java";
        String inputFile = args[0];

        double startTime = System.currentTimeMillis();
        int numProcesses = Integer.parseInt(args[1]);

        int numPoints = 0;
        try {
            PointStore pointStore;
            if (inputFile.endsWith(".dat")) {
                pointStore = new BinPointStore(inputFile);
            } else {
                pointStore = new TextPointStore(inputFile);
            }

            numPoints = pointStore.numPoints();
            pointStore.close();
        } catch (Exception e) {
            System.out.println("Error reading points from file: " + e.getMessage());
            return;
        }

        ProcessBuilder pb;
        int total = 0;
        double countTime = 0;

        // Divides the points among the processes
        try {

            int chunkSize = (numPoints + numProcesses - 1) / numProcesses;
            Process[] processes = new Process[numProcesses];

            // Start each process with their share of points to count
            for (int i = 0; i < numProcesses; i++) {
                int chunkStart = i * chunkSize;
                int chunkEnd = Math.min(chunkStart + chunkSize, numPoints);
                if (chunkStart >= numPoints) {
                    break;
                }

                pb = new ProcessBuilder(javaCommand, "-classpath", classpath, "com.tryright.Triangles",
                        inputFile, Integer.toString(chunkStart), Integer.toString(chunkEnd), "Process");
                processes[i] = pb.start();

            }

            // Read the output from each process and combine the results
            for (Process p : processes) {

                if (p == null) {
                    continue;
                }
                BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line = reader.readLine();
                if (line != null) {
                    try {
                        String[] output = line.split(",");
                        total += Integer.parseInt(output[0]);
                        // countTime += Double.parseDouble(output[1]);
                    } catch (Exception e) {
                        System.out.println("Error parsing output from process: " + line);
                    }
                    // readTime += Double.parseDouble(output[2]);
                }
                p.waitFor();
            }

            double endTime = System.currentTimeMillis();
            countTime = endTime - startTime;

            // writes the output to test//output.txt
            Triangles.writeOutput("ProcessTriangles with " + numProcesses + " processes", countTime, total,
                    numPoints);

            System.out.println(total);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
