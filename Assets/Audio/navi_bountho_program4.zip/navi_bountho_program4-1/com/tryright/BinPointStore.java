package com.tryright;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

/**
 * Name: Navi Bountho
 * Date: 2/19/2026
 * Professor: Dr. Donahoo
 * Description: BinPointStore implements PointStore interface to read points
 * from a binary file (dat).
 */

public class BinPointStore implements PointStore {

    private int numPoints;
    private RandomAccessFile file;
    private FileChannel channel;
    private MappedByteBuffer buffer;

    public BinPointStore(String filename) throws IOException {

        if (filename == null || filename.isEmpty()) {
            throw new IllegalArgumentException("Filename cannot be null or empty");
        }
        File f = new File(filename);
        if (!f.exists()) {
            throw new IOException("File not found: " + filename);
        } else if (f.canRead() == false) {
            throw new IOException("File not readable: " + filename);
        }

        try {

            file = new RandomAccessFile(filename, "r");
            channel = file.getChannel();

            long size = channel.size();

            if (size % 8 != 0) {
                close();
                throw new IOException("File Size must be a have 4 bytes for X and 4 Bytes for Y.");
            }

            numPoints = (int) (size / 8);

            if (numPoints > 0) {
                buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, size);
            }

        } catch (IOException e) {
            close();
            throw e;
        } catch (Exception e) {
            close();
            throw new IOException("Error reading file: " + filename, e);
        }
    }

    @Override
    public void close() {
        try {
            if (channel != null) {
                channel.close();
            }
            if (file != null) {
                file.close();
            }

        } catch (IOException io) {

        }

    }

    @Override
    public int numPoints() {
        return numPoints;
    }

    @Override
    public int getX(int idx) {
        if (buffer == null || idx < 0 || idx >= numPoints) {
            throw new IndexOutOfBoundsException("Invalid index: " + idx);
        }
        return buffer.getInt(idx * 8);
    }

    @Override
    public int getY(int idx) {
        if (buffer == null || idx < 0 || idx >= numPoints) {
            throw new IndexOutOfBoundsException("Invalid index: " + idx);
        }
        return buffer.getInt((idx * 8) + 4);
    }

}