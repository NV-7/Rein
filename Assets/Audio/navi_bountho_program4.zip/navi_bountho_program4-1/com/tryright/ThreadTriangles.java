package com.tryright;

/**
 * Name: Navi Bountho
 * Date: 2/19/2026
 * Professor: Dr. Donahoo
 * Counts the number of right triangles in a set of points using multithreading
 */

class ThreadTriangles implements Runnable {

    int start, end;
    PointStore pointStore;
    int total = 0;

    /**
     * Constructor for ThreadTriangles class
     * 
     * @param pointStore PointStore object containing the points to process
     * @param start      Starting index for this thread
     * @param end        Ending index for this thread
     */
    ThreadTriangles(PointStore pointStore, int start, int end) {
        this.pointStore = pointStore;
        this.start = start;
        this.end = end;
    }

    public static void main(String[] args) {

        // Validates the arguments before proceeding
        double startTime = System.currentTimeMillis();
        if (Triangles.isValid(args) == false) {
            System.out.println(Triangles.errorMessage);
            return;
        }

        // Validates the points before proceeding
        PointStore pointStore;

        try {
            if (args[0].endsWith(".dat")) {
                pointStore = new BinPointStore(args[0]);
            } else {
                pointStore = new TextPointStore(args[0]);
            }
        } catch (Exception e) {
            System.out.println("Error reading points from file: " + e.getMessage());
            return;
        }

        // Set up for threads and divide the work among them
        // each thread share the same array of points
        int numOfPoints = pointStore.numPoints();
        int numThreads = Integer.parseInt(args[1]);
        int chunkSize = (numOfPoints + numThreads - 1) / numThreads;

        ThreadTriangles[] jobs = new ThreadTriangles[numThreads];
        Thread[] threads = new Thread[numThreads];
        int totalSum = 0;

        // Initialize threads with their share of points to count
        for (int i = 0; i < numThreads; i++) {

            int start = i * chunkSize;
            int end = Math.min(start + chunkSize, numOfPoints);

            if (start >= numOfPoints) {
                break;
            }

            jobs[i] = new ThreadTriangles(pointStore, start, end);
            threads[i] = new Thread(jobs[i]);
            threads[i].start();
        }

        // Wait for threads to finish and combine the results.
        for (int i = 0; i < numThreads; i++) {
            try {

                if (threads[i] == null) {
                    continue;
                }

                threads[i].join();
                totalSum += jobs[i].total;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        pointStore.close();

        double endTime = System.currentTimeMillis();

        // Output the results to test//output.txt
        Triangles.writeOutput("ThreadTriangles with " + numThreads + " threads", endTime - startTime,
                totalSum, numOfPoints);

        System.out.println(totalSum);
    }

    // run override method for Runnable interface. Calls count from Triangles class
    @Override
    public void run() {
        total += Triangles.count(pointStore, start, end);
    }

}