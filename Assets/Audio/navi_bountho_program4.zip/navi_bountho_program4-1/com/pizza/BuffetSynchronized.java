/**
 * Name: Navi Bountho
 * Class: Operating Systems
 * Describtion: Implements the buffet interface using synchronized methods. 
 */
package com.pizza;

import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;

public class BuffetSynchronized implements Buffet {

  private int maxSlices;
  private boolean closed = false;
  private LinkedList<SliceType> slices = new LinkedList<>();
  private int numVegWaiting = 0;

  public BuffetSynchronized(int maxSlices) {
    if (maxSlices < 0) {
      throw new IllegalArgumentException("Must be a positive number of slices");
    }
    this.maxSlices = maxSlices;
  }

  @Override
  public synchronized List<SliceType> TakeAny(int desired) {

    if (desired < 0 || desired > maxSlices) {
      throw new IllegalArgumentException("Desired number must be between 0 and " + maxSlices);
    }

    boolean interrupted = false;

    LinkedList<SliceType> ret = new LinkedList<>();
    while (closed == false && canTakeAny(desired) == false) {
      try {
        wait();
      } catch (InterruptedException e) {
        // TODO Auto-generated catch block
        interrupted = true;
      }
    }

    if (interrupted) {
      Thread.currentThread().interrupt();
    }

    if (closed == true) {
      return null;
    }

    Iterator<SliceType> i = slices.iterator();
    while (i.hasNext() && ret.size() < desired) {
      SliceType slice = i.next();
      if (numVegWaiting > 0 && slice.isVeg() == true) {
        continue;
      }
      ret.add(slice);
      i.remove();
    }

    notifyAll();
    return ret;
  }

  @Override
  public synchronized List<SliceType> TakeVeg(int desired) {
    if (desired < 0 || desired > maxSlices) {
      throw new IllegalArgumentException("Desired number must be between 0 and " + maxSlices);
    }

    boolean interrupted = false;

    numVegWaiting++;
    LinkedList<SliceType> ret = new LinkedList<>();

    try {
      while (closed == false && canTakeVeg(desired) == false) {
        try {
          wait();
        } catch (InterruptedException e) {
          // TODO Auto-generated catch block
          interrupted = true;
        }
      }
    } finally {
      numVegWaiting--;
    }

    if (interrupted) {
      Thread.currentThread().interrupt();
    }

    if (closed == true) {
      return null;
    }

    Iterator<SliceType> i = slices.iterator();
    while (i.hasNext() && ret.size() < desired) {
      SliceType slice = i.next();
      if (slice.isVeg() == true) {
        ret.add(slice);
        i.remove();

      }
    }

    notifyAll();
    return ret;
  }

  @Override
  public synchronized boolean AddPizza(int count, SliceType stype) {
    if (count < 0) {
      throw new IllegalArgumentException("Positive Count Only");
    }
    if (stype == null) {
      throw new NullPointerException("stype");
    }

    boolean interrupted = false;
    int added = 0;
    while (added < count && closed == false) {
      while (slices.size() >= maxSlices && closed == false) {
        try {
          wait();
        } catch (InterruptedException e) {
          // TODO Auto-generated catch block
          interrupted = true;
        }
      }
      if (closed == true) {
        break;
      }

      while (added < count && slices.size() < maxSlices) {
        slices.add(stype);
        added++;
      }
      notifyAll();
    }
    if (interrupted) {
      Thread.currentThread().interrupt();
    }

    return !closed;
  }

  @Override
  public synchronized void close() {
    closed = true;
    notifyAll();
  }

  private int numVegSlices() {
    int count = 0;
    for (SliceType slice : slices) {
      if (slice.isVeg() == true) {
        count++;
      }
    }
    return count;
  }

  private boolean canTakeAny(int desired) {
    if (numVegWaiting > 0) {
      return slices.size() - numVegSlices() >= desired;
    }
    return slices.size() >= desired;
  }

  private boolean canTakeVeg(int desired) {
    return numVegSlices() >= desired;
  }

}
