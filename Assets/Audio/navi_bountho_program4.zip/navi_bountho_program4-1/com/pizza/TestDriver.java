/**
 * Name: Navi Boutho
 * Course: Operating Systems
 * Description : Driver that tests the different synchronization implementations of the buffet.
 */
package com.pizza;

import java.util.List;
import java.util.random.RandomGenerator;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

public class TestDriver {
    public static void main(String[] args) {

        Buffet buffet = new BuffetSynchronized(10); // Change to different implementation

        addVegPizzaTest(buffet);
        buffet = createBuffet(buffet);
        addNonVegPizzaTest(buffet);
        buffet = createBuffet(buffet);
        try {
            vegWaitTest(buffet);
            buffet = createBuffet(buffet);
            maxSlicesTest(buffet);
            buffet = createBuffet(buffet);
            consumersCloseTest(buffet);
            buffet = createBuffet(buffet);
            serverCloseTest(buffet);
            buffet = createBuffet(buffet);
        } catch (InterruptedException e) {
            System.out.println("Test was interrupted");
        }

        System.out.println("Simiulate open buffet test 5 times");
        try {
            for (int i = 0; i < 5; i++) {
                System.out.println("Open buffet test iteration " + (i + 1));
                buffet = createBuffet(buffet);
                if (openBuffetTest(buffet) == false) {
                    System.out.println("Open buffet test failed on iteration " + (i + 1));
                }
            }

        } catch (InterruptedException e) {
            System.out.println("Test was interrupted");
        }

    }

    /**
     * Helper method to create a buffet instance of the specified class
     */
    private static Buffet createBuffet(Buffet buffet) {
        if (buffet.getClass().getName().equals("com.pizza.BuffetLock")) {
            return new BuffetLock(10);
        } else if (buffet.getClass().getName().equals("com.pizza.BuffetSemaphore")) {
            return new BuffetSemaphore(10);
        } else if (buffet.getClass().getName().equals("com.pizza.BuffetSynchronized")) {
            return new BuffetSynchronized(10);
        } else {
            throw new IllegalArgumentException("Invalid buffet type");
        }
    }

    /**
     * Test adds a veg slice and checks if a veg slice was taken.
     * 
     * @param buffetType the implemeentation of buffet
     * @return true if test passed, false if test failed
     */
    public static boolean addVegPizzaTest(Buffet buffetType) {

        String name = buffetType.getClass().getName();
        buffetType.AddPizza(1, SliceType.Veggie);
        List<SliceType> vegSlice = buffetType.TakeVeg(1);

        if (vegSlice == null || vegSlice.isEmpty()) {
            System.out.println("Failed: " + name + " TakeVeg returned null or empty");
            return false;
        }

        if (vegSlice.get(0).isVeg() == false) {
            System.out.println("Failed: +" + name + " TakeVeg did not return a veg slice");
            return false;
        }

        System.out.println("Pass: " + name + " Added a veg slice and veg was taken");
        buffetType.close();
        return true;
    }

    /**
     * Test adds a nonVeg slice and checks if TakeAny returns a nonVeg slice.
     * 
     * @param buffetType Buffet implementation to test
     * @return true if test passed, false if test failed
     */
    public static boolean addNonVegPizzaTest(Buffet buffetType) {
        String name = buffetType.getClass().getName();
        buffetType.AddPizza(1, SliceType.Meat);
        List<SliceType> meatSlice = buffetType.TakeAny(1);

        if (meatSlice == null || meatSlice.isEmpty()) {
            System.out.println("Failed: " + name + " TakeAny returned null or empty");
            return false;
        }
        if (meatSlice.get(0).isVeg()) {
            System.out.println("Failed: " + name + " TakeAny returned a veg slice");
            return false;
        }

        System.out.println("Pass: " + name + " Added a non-veg slice and non-veg was taken");
        buffetType.close();

        return true;
    }

    // This test checks whether a veg will wait for veg slices and non-veg will not
    // take veg slices when a veg is waiting.
    // Ensures that a veg will only take a veg slices.
    /**
     * Test Checks whether a veg consumer waits for a veg slice.
     * Non-veg consumers will not take veg slices when a veg is waiting.
     * 
     * @param buffet
     * @return
     * @throws InterruptedException
     */
    public static boolean vegWaitTest(Buffet buffet) throws InterruptedException {

        String name = buffet.getClass().getName();
        boolean ret = false;
        buffet.AddPizza(5, SliceType.Veggie);

        AtomicBoolean vegThreadFinished = new AtomicBoolean(false);
        AtomicBoolean onlyVegTaken = new AtomicBoolean(false);
        AtomicBoolean correctSliceCount = new AtomicBoolean(false);
        CountDownLatch latch = new CountDownLatch(1);

        Thread vegThread = new Thread(() -> {
            latch.countDown();
            List<SliceType> slices = buffet.TakeVeg(7);
            if (slices != null && slices.size() == 7) {
                boolean allVeg = true;
                correctSliceCount.set(true);
                for (SliceType s : slices) {
                    if (!s.isVeg()) {
                        allVeg = false;
                        break;
                    }
                }
                onlyVegTaken.set(allVeg);
            }
            vegThreadFinished.set(true);

        }, "VegThread");

        vegThread.start();
        latch.await();
        Thread.sleep(2000);

        buffet.AddPizza(2, SliceType.Meat);
        List<SliceType> taken = buffet.TakeAny(2);

        boolean vegSliceTaken = false;
        if (taken != null) {
            for (SliceType s : taken) {
                if (s.isVeg()) {
                    vegSliceTaken = true;
                    System.out.println("Failed: " + name + " TakeAny took a veg slice when veg consumer was waiting");
                    break;
                }
            }
        }

        if (vegSliceTaken == true) {
            buffet.close();
            vegThread.join(2000);
            return false;
        }

        buffet.AddPizza(2, SliceType.Veggie);
        vegThread.join(2000);

        if (vegThreadFinished.get() == false) {
            System.out.println("Failed: " + name + " Veg consumer did not finish. Hanged");
            ret = false;
        } else if (correctSliceCount.get() == false) {
            System.out.println("Failed: " + name + " Veg consumer did not take the correct number of slices");
        } else if (onlyVegTaken.get() == false) {
            System.out.println("Failed: " + name + " Veg consumer took a non-veg slice");
            ret = false;
        } else {
            System.out.println("Pass: " + name + " Veg consumer waited for veg slices and only took veg slices");
            ret = true;
        }

        buffet.close();
        return ret;
    }

    public static boolean maxSlicesTest(Buffet buffet) throws InterruptedException {

        String name = buffet.getClass().getName();
        boolean ret = false;
        buffet.AddPizza(10, SliceType.Veggie);

        AtomicBoolean blocks = new AtomicBoolean(false);
        AtomicBoolean isFinished = new AtomicBoolean(false);
        CountDownLatch latch = new CountDownLatch(1);

        Thread serverThread = new Thread(() -> {
            latch.countDown();

            boolean added = buffet.AddPizza(1, SliceType.Veggie);
            if (added == true) {
                blocks.set(true);
            }
            isFinished.set(true);

        });

        serverThread.start();
        latch.await();
        Thread.sleep(2000);

        buffet.TakeVeg(1);
        serverThread.join(2000);

        if (serverThread.isAlive()) {
            System.out.println("Fail: " + name + " Server thread is still blocked. Hanged");
            ret = false;
        } else if (isFinished.get() == false) {
            System.out.println("Fail: " + name + " Server thread did not finish/Is still blocked");
            ret = false;
        } else if (blocks.get() == true) {
            System.out.println("Pass: " + name + " Server thread was blocked until a slice was taken");
            ret = true;
        } else {
            System.out.println("Fail: " + name + " Server thread was not blocked when buffet was at max capacity");
            ret = false;
        }

        buffet.close();
        return ret;
    }

    /**
     * Tests that confirms consumer threads are closed properly.
     * 
     * @param buffet Implementation of buffet to test
     * @return true if consumer threads are closed, false if consumer threads are
     *         blocked after cloee()
     * @throws InterruptedException
     */
    public static boolean consumersCloseTest(Buffet buffet) throws InterruptedException {

        String name = buffet.getClass().getName();
        CountDownLatch latch = new CountDownLatch(2);
        AtomicInteger nullCount = new AtomicInteger(0);

        // VegThread will block to wait for veg slices.
        Thread vegThread = new Thread(() -> {
            latch.countDown();
            if (buffet.TakeVeg(5) == null) {
                nullCount.getAndIncrement();
            }
        });
        // TakeAny thread will block to wait for any slices.
        Thread takeAnyThread = new Thread(() -> {
            latch.countDown();
            if (buffet.TakeAny(5) == null) {
                nullCount.getAndIncrement();
            }
        });

        vegThread.start();
        takeAnyThread.start();
        latch.await();
        Thread.sleep(2000);
        buffet.close();

        vegThread.join(2000);
        takeAnyThread.join(2000);

        if (vegThread.isAlive() || takeAnyThread.isAlive()) {
            System.out.println("Fail: " + name + " Consumer threads are still blocked after close(). Hanged");
            return false;
        }
        if (nullCount.get() == 2) {
            System.out.println("Pass: " + name + " Both consumer threads returned null after close()");
            return true;
        } else {
            System.out.println("Fail: " + name + " Both consumer threads did not return null after close()");
            return false;
        }

    }

    /**
     * Test confims that server threads are closed properly after close()
     * 
     * @param buffet implementation of buffet to test
     * @return true is server threads are closed properly, false if server threads
     *         are blocked after close()
     * @throws InterruptedException
     */
    public static boolean serverCloseTest(Buffet buffet) throws InterruptedException {

        String name = buffet.getClass().getName();
        CountDownLatch latch = new CountDownLatch(1);
        AtomicBoolean serverAddedPizza = new AtomicBoolean(false);

        buffet.AddPizza(10, SliceType.Veggie);

        // Server blocks when adding pizza to a full buffet.
        Thread serverThread = new Thread(() -> {

            latch.countDown();
            if (buffet.AddPizza(1, SliceType.Veggie) == false) {
                serverAddedPizza.set(true);
            }
        });

        serverThread.start();
        latch.await();
        Thread.sleep(2000);

        buffet.close();
        serverThread.join(2000);

        if (serverThread.isAlive()) {
            System.out.println("Fail: " + name + " Server thread is still blocked after close(). Hanged");
        }
        if (serverAddedPizza.get() == true) {
            System.out.println("Pass: " + name + " Server thread was unblocked and did not add pizza after close()");
            return true;
        } else {
            System.out.println("Fail: " + name + " Server thread was unblocked but added pizza after close()");
            return false;
        }

    }

    /**
     * Test that run multiple consumer and server threads to make sure the buffet
     * implementation works. Creates 10 veg consumers, 10 any consumers,
     * and 5 servers. Servers add a random number (1,3) of slices of a random type.
     * Conssumers take a random number (1,3) of slices.
     * Number of slices taken shouldn't be larger than number of slices added.
     * 
     * @param buffet Implementation of buffet
     * @return
     * @throws InterruptedException
     */
    public static boolean openBuffetTest(Buffet buffet) throws InterruptedException {

        int vegConsumers = 10;
        int anyConsumers = 10;
        int servers = 5;
        CountDownLatch latch = new CountDownLatch(1);
        RandomGenerator rand = RandomGenerator.getDefault();

        Thread[] t = new Thread[vegConsumers + anyConsumers + servers];
        SliceType[] slices = { SliceType.Veggie, SliceType.Meat, SliceType.Cheese };

        AtomicInteger countSlices = new AtomicInteger(0);
        AtomicInteger countSlicesConsumed = new AtomicInteger(0);

        // Create servers that a random number of slices of a random type
        for (int i = 0; i < servers; i++) {
            SliceType sliceType = slices[rand.nextInt(slices.length)];
            t[i] = new Thread(() -> {

                try {
                    latch.await();
                } catch (InterruptedException e) {
                    return;
                }
                int slicesToAdd = rand.nextInt(1, 4);
                if (buffet.AddPizza(slicesToAdd, sliceType)) {
                    countSlices.getAndAdd(slicesToAdd);
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    return;
                }
            });
        }

        // Create consumers that take a random number of slices.

        for (int i = 0; i < vegConsumers; i++) {
            t[servers + i] = new Thread(() -> {
                try {
                    latch.await();
                } catch (InterruptedException e) {
                    return;
                }
                List<SliceType> consume = buffet.TakeVeg(rand.nextInt(1, 4));
                if (consume != null) {
                    countSlicesConsumed.getAndAdd(consume.size());
                }
            });
        }

        for (int i = 0; i < anyConsumers; i++) {
            t[i + servers + vegConsumers] = new Thread(() -> {
                try {
                    latch.await();
                } catch (InterruptedException e) {
                    return;
                }
                List<SliceType> taken = buffet.TakeAny(rand.nextInt(1, 4));
                if (taken != null) {
                    countSlicesConsumed.getAndAdd(taken.size());
                }
            });
        }

        for (Thread thread : t) {
            thread.start();
        }

        // Thread sleep for 5 seconds to let other threads run.
        latch.countDown();
        Thread.sleep(5000);
        buffet.close();

        for (Thread thread : t) {
            thread.join(3000);
        }

        // Check if thread still living after close
        boolean isAlive = false;
        for (Thread thread : t) {
            if (thread.isAlive()) {
                isAlive = true;
                break;
            }
        }

        if (isAlive) {
            System.out.println("Fail: Server or consumer threads are still alive after close(). Hanged");
            return false;
        }

        if (countSlicesConsumed.get() > countSlices.get()) {
            System.out.println("Fail: More slices were consumed than added. Consumed: " + countSlicesConsumed.get()
                    + " Added: " + countSlices.get());
            return false;

        }
        System.out.println("Open buffet test done." + "\nCount of slices added: "
                + countSlices.get() + "\nCount of slices consumed: " + countSlicesConsumed.get());
        return true;

    }
}
