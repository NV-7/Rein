/**
 * Name: Navi Bountho
 * Class: Operating Systems
 * Description: Implements the buffet interface using locks and conditions.
 */
package com.pizza;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;

public class BuffetLock implements Buffet {

    private final int maxSlices;
    private final Lock lock = new ReentrantLock();
    private final Condition cond = lock.newCondition();
    private final LinkedList<SliceType> slices = new LinkedList<>();
    private boolean closed = false;
    private int vegWaiters = 0;

    public BuffetLock(int numSlices) {
        if (numSlices < 0) {
            throw new IllegalArgumentException("numSlices < 0");
        }
        this.maxSlices = numSlices;
    }

    @Override
    public List<SliceType> TakeAny(int desired) {
        if (desired < 0 || desired > maxSlices) {
            throw new IllegalArgumentException("desired out of range");
        }
        if (desired == 0) {
            return new ArrayList<>();
        }
        lock.lock();
        try {
            while (!closed && !canTakeAny(desired)) {
                cond.awaitUninterruptibly();
            }
            if (closed) {
                return null;
            }

            List<SliceType> result = new ArrayList<>(desired);
            if (vegWaiters == 0) {
                for (int i = 0; i < desired; i++) {
                    result.add(slices.removeFirst());
                }
            } else {
                int taken = 0;
                var iterator = slices.iterator();
                while (iterator.hasNext() && taken < desired) {
                    SliceType slice = iterator.next();
                    if (slice.isVeg()) {
                        continue;
                    }
                    result.add(slice);
                    iterator.remove();
                    taken++;
                }
            }

            cond.signalAll();
            return result;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public List<SliceType> TakeVeg(int desired) {
        if (desired < 0 || desired > maxSlices) {
            throw new IllegalArgumentException("desired out of range");
        }
        if (desired == 0) {
            return new ArrayList<>();
        }
        lock.lock();
        try {
            while (!closed && countVegSlices() < desired) {
                vegWaiters++;
                try {
                    cond.awaitUninterruptibly();
                } finally {
                    vegWaiters--;
                }
            }
            if (closed) {
                return null;
            }

            List<SliceType> result = new ArrayList<>(desired);
            int taken = 0;
            var iterator = slices.iterator();
            while (iterator.hasNext() && taken < desired) {
                SliceType slice = iterator.next();
                if (!slice.isVeg()) {
                    continue;
                }
                result.add(slice);
                iterator.remove();
                taken++;
            }

            cond.signalAll();
            return result;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean AddPizza(int count, SliceType stype) {
        if (count < 0) {
            throw new IllegalArgumentException("count < 0");
        }
        if (stype == null) {
            throw new NullPointerException("stype");
        }

        lock.lock();
        try {
            if (closed) {
                return false;
            }
            int remaining = count;
            while (remaining > 0 && !closed) {
                while (!closed && slices.size() == maxSlices) {
                    cond.awaitUninterruptibly();
                }
                if (closed) {
                    return false;
                }

                int room = maxSlices - slices.size();
                int toAdd = Math.min(room, remaining);
                for (int i = 0; i < toAdd; i++) {
                    slices.addLast(stype);
                }
                remaining -= toAdd;
                cond.signalAll();
            }
            return !closed;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void close() {
        lock.lock();
        try {
            closed = true;
            cond.signalAll();
        } finally {
            lock.unlock();
        }
    }

    private boolean canTakeAny(int desiredAmt) {
        if (vegWaiters == 0) {
            return slices.size() >= desiredAmt;
        }
        return countNonVegSlices() >= desiredAmt;
    }

    private int countVegSlices() {
        int count = 0;
        for (SliceType slice : slices) {
            if (slice.isVeg()) {
                count++;
            }
        }
        return count;
    }

    private int countNonVegSlices() {
        int count = 0;
        for (SliceType slice : slices) {
            if (!slice.isVeg()) {
                count++;
            }
        }
        return count;
    }
}
