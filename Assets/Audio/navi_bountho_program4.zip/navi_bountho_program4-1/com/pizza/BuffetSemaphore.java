/**
 * Name: Navi Bountho
 * Class: Operating Systems
 * Description: Implements the buffet interface using semaphores.
 */
package com.pizza;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.Semaphore;

public class BuffetSemaphore implements Buffet {

    private int maxSlices;
    private LinkedList<SliceType> slices = new LinkedList<>();
    private boolean closed = false;
    // Semaphore to provide mutal exclusion.
    private Semaphore mutex = new Semaphore(1);

    private Semaphore vegWating = new Semaphore(0);
    private Semaphore nonVegWating = new Semaphore(0);
    private Semaphore servers = new Semaphore(0);
    private int minNumtoSatisfyVeg = Integer.MAX_VALUE;
    private int minNumToSatisfyNonVeg = Integer.MAX_VALUE;
    private int numVegWaiting = 0;
    private int numNonVegWaiting = 0;
    private int numServerWaiting = 0;

    public BuffetSemaphore(int numSlices) {
        if (numSlices < 0) {
            throw new IllegalArgumentException("Number of slices must be a positive number");
        }
        this.maxSlices = numSlices;
    }

    @Override
    public List<SliceType> TakeAny(int willTake) {

        if (willTake < 0 || willTake > maxSlices) {
            throw new IllegalArgumentException("Desired number must be between 0 and " + maxSlices);
        }

        mutex.acquireUninterruptibly();
        // If not closed and not able to take, wait
        while (closed == false && canTakeAny(willTake) == false) {
            numNonVegWaiting++;
            minNumToSatisfyNonVeg = Math.min(minNumToSatisfyNonVeg, willTake);
            releaseSem();
            nonVegWating.acquireUninterruptibly();
            numNonVegWaiting--;
            if (numNonVegWaiting == 0) {
                minNumToSatisfyNonVeg = Integer.MAX_VALUE;
            }

        }

        if (closed) {
            releaseSem();
            return null;
        }

        // If not closed and able to take

        List<SliceType> ret = new ArrayList<>();
        Iterator<SliceType> i = slices.iterator();

        while (i.hasNext() && ret.size() < willTake) {
            SliceType slice = i.next();

            // check if Veg are waiting
            if (numVegWaiting > 0 && slice.isVeg()) {
                continue;
            }

            ret.add(slice);
            i.remove();

        }

        releaseSem();
        return ret;
    }

    @Override
    public List<SliceType> TakeVeg(int willTake) {

        if (willTake < 0 || willTake > maxSlices) {
            throw new IllegalArgumentException("Desired number must be between 0 and " + maxSlices);
        }

        mutex.acquireUninterruptibly();
        // If not closed and not able to take, wait
        while (closed == false && canTakeVeg(willTake) == false) {
            numVegWaiting++;
            minNumtoSatisfyVeg = Math.min(minNumtoSatisfyVeg, willTake);
            releaseSem();
            vegWating.acquireUninterruptibly();
            numVegWaiting--;
            if (numVegWaiting == 0) {
                minNumtoSatisfyVeg = Integer.MAX_VALUE;
            }
        }

        if (closed) {
            releaseSem();
            return null;
        }

        // If not closed and able to take

        List<SliceType> ret = new ArrayList<>();
        Iterator<SliceType> i = slices.iterator();

        while (i.hasNext() && ret.size() < willTake) {
            SliceType slice = i.next();

            if (slice.isVeg()) {
                ret.add(slice);
                i.remove();
            }

        }

        releaseSem();
        return ret;
    }

    @Override
    public boolean AddPizza(int count, SliceType stype) {

        if (count < 0) {
            throw new IllegalArgumentException("Positive Count Only");
        }
        if (stype == null) {
            throw new IllegalArgumentException("SliceType cannot be null");
        }
        mutex.acquireUninterruptibly();

        int numAdded = 0;
        while (numAdded < count && closed == false) {

            while (slices.size() == maxSlices && closed == false) {
                numServerWaiting++;
                releaseSem();
                servers.acquireUninterruptibly();
                numServerWaiting--;
            }

            if (closed == true) {
                break;
            }

            while (numAdded < count && slices.size() < maxSlices) {
                slices.add(stype);
                numAdded++;
            }

            if (numAdded < count && closed == false) {
                releaseSem();
                mutex.acquireUninterruptibly();
            }
        }

        boolean res = false;
        if (numAdded > 0 || closed == false) {
            res = true;
        }
        releaseSem();
        return !closed && res;

    }

    @Override
    public void close() {

        mutex.acquireUninterruptibly();
        closed = true;
        releaseSem();
    }

    public int numVegSlices() {
        int count = 0;

        for (SliceType slice : slices) {
            if (slice.isVeg()) {
                count++;
            }
        }

        return count;
    }

    public int numNonVegSlices() {
        int count = 0;

        for (SliceType slice : slices) {
            if (!slice.isVeg()) {
                count++;
            }
        }
        return count;
    }

    public boolean canTakeVeg(int willTake) {

        if (numVegSlices() >= willTake) {
            return true;
        }

        return false;
    }

    public boolean canTakeAny(int willTake) {
        if (numVegWaiting > 0) {
            return slices.size() - numVegSlices() >= willTake;
        }
        return slices.size() >= willTake;
    }

    public void releaseSem() {
        // When Closed, release all semaphore
        if (closed) {
            if (numVegWaiting > 0) {
                vegWating.release();
            } else if (numNonVegWaiting > 0) {
                nonVegWating.release();
            } else if (numServerWaiting > 0) {
                servers.release();
            } else {
                mutex.release();
            }
        } else if (numVegWaiting > 0 && numVegSlices() >= minNumtoSatisfyVeg) {
            vegWating.release();
        } else if (numNonVegWaiting > 0 && canTakeAny(minNumToSatisfyNonVeg)) {
            nonVegWating.release();
        } else if (numServerWaiting > 0 && slices.size() < maxSlices) {
            servers.release();
        } else {
            mutex.release();
        }

    }
}
