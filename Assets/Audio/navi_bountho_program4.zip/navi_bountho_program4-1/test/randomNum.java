/**
 * Name: Navi Bountho
 * Date: 2/19/2026
 * Professor: Dr. Jeff Donahoo
 * Course: CS4180 - Operating Systems
 * Generates a file with random points in a 2D Cartesian plane.
 */
package test;

import java.io.FileWriter;
import java.util.Random;
import java.util.Set;
import java.util.HashSet;

public class randomNum {
    public static void main(String[] args) {
        try {

            if (args.length == 0) {
                System.out.println("Please provide the number of points to generate as an argument");
                return;
            }

            FileWriter writer = new FileWriter("test//ScaleTest.txt");

            int n = Integer.parseInt(args[0]); // Number of points to generate
            writer.write(n + "\n");
            Random rand = new Random();
            Set<String> points = new HashSet<>();

            while (points.size() < n) {
                int x = rand.nextInt(100000); // Generate random x coordinate
                int y = rand.nextInt(100000); // Generate random y coordinate
                String point = x + " " + y;
                if (!points.contains(point)) {
                    points.add(point);
                    writer.write(point + "\n"); // Write the point to the file
                }
            }
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
