
package test;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

class GenDatFile {

    public static void main(String[] args) {

        int[][] points = {
                { 0, 0 },
                { 0, 4 },
                { 3, 0 },
                { 3, 4 }
        };

        // Saving to the test directory as required by your assignment
        String filename = "test/testdata.dat";

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(filename))) {
            for (int[] p : points) {
                dos.writeInt(p[0]); // Writes 4-byte X in Big-Endian
                dos.writeInt(p[1]); // Writes 4-byte Y in Big-Endian
            }
            System.out.println("Successfully generated " + filename + " with " + points.length + " points.");
            System.out.println("Expected right triangle count for this file: 4");

        } catch (IOException e) {
            System.out.println("Error writing file: " + e.getMessage());
            System.out.println("Hint: Make sure the 'test' directory exists in your root folder!");
        }
    }
}
